# TEST MITRA — GitHub APK Build

This package is prepared for a simple GitHub Actions debug APK build.

## Easiest method
1. Extract this ZIP on your phone/computer.
2. Upload the **contents** to the root of a GitHub repository (so `settings.gradle.kts` is in the repository root).
3. Open **Actions → Build TEST MITRA APK → Run workflow**.
4. After it finishes, open the run and download the **test-mitra-debug-apk** artifact.

The workflow also supports a repository containing this ZIP as a file: it automatically extracts the first ZIP it finds and builds the Gradle project inside it.

## Supabase
The app can use Supabase settings saved from the app's settings screen. If GitHub repository secrets named `SUPABASE_URL` and `SUPABASE_ANON_KEY` exist, the workflow also passes them into BuildConfig. They are optional for compiling the APK.

## Important
- No Google Services plugin is required.
- No Room/KSP annotation processing is required. Local session/test data uses SharedPreferences.
- The app keeps the internet-required startup screen: when validated internet is unavailable, the main app does not open.

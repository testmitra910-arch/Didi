package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.Repository
import com.example.model.NotificationItem
import com.example.model.Question
import com.example.model.Test
import com.example.model.TestResultSummary
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class StudentTestState {
    object Idle : StudentTestState()
    object Loading : StudentTestState()
    data class Active(
        val test: Test,
        val questions: List<Question>,
        val attemptId: String,
        val currentQuestionIndex: Int,
        val selectedAnswers: Map<String, String?>,
        val remainingSeconds: Int,
        val targetEndTimeMillis: Long
    ) : StudentTestState()
    data class ResultReady(val summary: TestResultSummary) : StudentTestState()
    data class Error(val message: String) : StudentTestState()
}

class StudentViewModel(application: Application) : AndroidViewModel(application) {

    val repository = Repository(application)

    private val _publishedTests = MutableStateFlow<List<Test>>(emptyList())
    val publishedTests: StateFlow<List<Test>> = _publishedTests.asStateFlow()

    private val _notifications = MutableStateFlow<List<NotificationItem>>(emptyList())
    val notifications: StateFlow<List<NotificationItem>> = _notifications.asStateFlow()

    private val _myResults = MutableStateFlow<List<TestResultSummary>>(emptyList())
    val myResults: StateFlow<List<TestResultSummary>> = _myResults.asStateFlow()

    private val _testState = MutableStateFlow<StudentTestState>(StudentTestState.Idle)
    val testState: StateFlow<StudentTestState> = _testState.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private var timerJob: Job? = null

    fun loadPublishedTests(examTypeId: String) {
        viewModelScope.launch {
            _isLoading.value = true
            _publishedTests.value = repository.getTests(examTypeId, statusFilter = "published")
            _isLoading.value = false
        }
    }

    fun loadNotifications(examTypeId: String) {
        viewModelScope.launch {
            _isLoading.value = true
            _notifications.value = repository.getNotifications(examTypeId)
            _isLoading.value = false
        }
    }

    fun loadMyResults(studentProfileId: String) {
        viewModelScope.launch {
            _isLoading.value = true
            val studentInfo = repository.apiClient.getStudentByProfileId(studentProfileId)
            if (studentInfo != null) {
                _myResults.value = repository.getStudentResults(studentInfo.id)
            }
            _isLoading.value = false
        }
    }

    fun startTest(test: Test, studentProfileId: String) {
        viewModelScope.launch {
            _testState.value = StudentTestState.Loading
            try {
                val studentInfo = repository.apiClient.getStudentByProfileId(studentProfileId)
                    ?: throw Exception("વિદ્યાર્થી પ્રોફાઇલ મળી નથી.")

                val questions = repository.getQuestions(test.id)
                if (questions.isEmpty()) {
                    _testState.value = StudentTestState.Error("આ ટેસ્ટમાં હાલમાં કોઈ પ્રશ્નો નથી.")
                    return@launch
                }

                val (attempt, activeEntity) = repository.startTestAttempt(test, studentInfo.id)
                val answersMap = mutableMapOf<String, String?>()

                _testState.value = StudentTestState.Active(
                    test = test,
                    questions = questions,
                    attemptId = attempt.id,
                    currentQuestionIndex = 0,
                    selectedAnswers = answersMap,
                    remainingSeconds = test.durationMinutes * 60,
                    targetEndTimeMillis = activeEntity.targetEndTimeMillis
                )

                startTimer(activeEntity.targetEndTimeMillis, attempt.id, test, questions, studentInfo.id)
            } catch (e: Exception) {
                _testState.value = StudentTestState.Error(e.message ?: "ટેસ્ટ શરૂ કરવામાં ભૂલ આવી.")
            }
        }
    }

    private fun startTimer(
        targetEndTimeMillis: Long,
        attemptId: String,
        test: Test,
        questions: List<Question>,
        studentId: String
    ) {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (true) {
                val current = System.currentTimeMillis()
                val remMs = targetEndTimeMillis - current
                val remSec = (remMs / 1000).toInt()

                if (remSec <= 0) {
                    // Auto-submit when timer expires
                    submitTest(attemptId, test, questions, studentId)
                    break
                }

                val currentActive = _testState.value as? StudentTestState.Active
                if (currentActive != null) {
                    _testState.value = currentActive.copy(remainingSeconds = remSec)
                }

                delay(1000)
            }
        }
    }

    fun selectOption(questionId: String, option: String) {
        val active = _testState.value as? StudentTestState.Active ?: return
        val updatedMap = active.selectedAnswers.toMutableMap()
        updatedMap[questionId] = option
        _testState.value = active.copy(selectedAnswers = updatedMap)

        viewModelScope.launch {
            repository.saveAnswerLocally(active.attemptId, questionId, option)
        }
    }

    fun navigateQuestion(delta: Int) {
        val active = _testState.value as? StudentTestState.Active ?: return
        val newIndex = (active.currentQuestionIndex + delta).coerceIn(0, active.questions.size - 1)
        _testState.value = active.copy(currentQuestionIndex = newIndex)
    }

    fun submitTestManually(studentProfileId: String) {
        val active = _testState.value as? StudentTestState.Active ?: return
        viewModelScope.launch {
            val studentInfo = repository.apiClient.getStudentByProfileId(studentProfileId)
            if (studentInfo != null) {
                submitTest(active.attemptId, active.test, active.questions, studentInfo.id)
            }
        }
    }

    private suspend fun submitTest(
        attemptId: String,
        test: Test,
        questions: List<Question>,
        studentId: String
    ) {
        timerJob?.cancel()
        _testState.value = StudentTestState.Loading
        try {
            val summary = repository.submitTestAttempt(attemptId, test, questions, studentId)
            _testState.value = StudentTestState.ResultReady(summary)
        } catch (e: Exception) {
            _testState.value = StudentTestState.Error(e.message ?: "ટેસ્ટ સબમિટ કરવામાં ભૂલ આવી.")
        }
    }

    fun resetTestState() {
        timerJob?.cancel()
        _testState.value = StudentTestState.Idle
    }
}

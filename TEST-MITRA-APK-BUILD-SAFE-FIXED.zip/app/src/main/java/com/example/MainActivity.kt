package com.example

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Refresh
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.local.LocalProfileEntity
import com.example.model.ExamType
import com.example.ui.screens.AdminDashboardScreen
import com.example.ui.screens.AdminExamTypesScreen
import com.example.ui.screens.AdminStudentMgmtScreen
import com.example.ui.screens.AdminTestsMgmtScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.SetupAdminDialog
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.StudentDashboardScreen
import com.example.ui.screens.SupabaseSettingsDialog
import com.example.ui.theme.TestMitraTheme
import com.example.viewmodel.AdminViewModel
import com.example.viewmodel.AuthState
import com.example.viewmodel.AuthViewModel
import com.example.viewmodel.StudentViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TestMitraTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    TestMitraApp()
                }
            }
        }
    }
}

@Composable
fun TestMitraApp() {
    val (hasInternet, retryInternetCheck) = rememberInternetConnection()

    // Do not initialize the authenticated app/network stack while offline.
    // The user must first restore internet connectivity.
    if (!hasInternet) {
        NoInternetScreen(onRetry = retryInternetCheck)
        return
    }

    val authViewModel: AuthViewModel = viewModel()
    var showSplash by remember { mutableStateOf(true) }
    var currentAdminScreen by remember { mutableStateOf("DASHBOARD") }
    var selectedExamTypeForTests by remember { mutableStateOf<ExamType?>(null) }
    var currentStudentScreen by remember { mutableStateOf("STUDENT_DASHBOARD") }
    var showSupabaseConfigDialog by remember { mutableStateOf(false) }
    var showSetupAdminDialog by remember { mutableStateOf(false) }

    val authState by authViewModel.authState.collectAsState()
    // Create feature ViewModels only after authentication. This avoids unnecessary
    // database/network initialization during the launch screen.
    val adminViewModel: AdminViewModel? = if (authState is AuthState.Authenticated && (authState as AuthState.Authenticated).profile.role != "student") viewModel() else null
    val studentViewModel: StudentViewModel? = if (authState is AuthState.Authenticated && (authState as AuthState.Authenticated).profile.role == "student") viewModel() else null

    if (showSplash) {
        SplashScreen(
            onSplashComplete = { showSplash = false }
        )
        return
    }

    if (showSupabaseConfigDialog) {
        SupabaseSettingsDialog(
            onDismiss = { showSupabaseConfigDialog = false },
            onSave = { url, key ->
                authViewModel.saveSupabaseConfig(url, key)
                showSupabaseConfigDialog = false
            }
        )
    }

    if (showSetupAdminDialog) {
        SetupAdminDialog(
            onDismiss = { showSetupAdminDialog = false },
            onSubmit = { name, mobile, pass ->
                authViewModel.setupFirstMainAdmin(name, mobile, pass)
                showSetupAdminDialog = false
            }
        )
    }

    when (val state = authState) {
        is AuthState.Initial, is AuthState.Loading -> {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        }
        is AuthState.Unauthenticated, is AuthState.Error -> {
            val errorMsg = (state as? AuthState.Error)?.message
            LoginScreen(
                onLoginSubmit = { mobile, pass -> authViewModel.login(mobile, pass) },
                onSetupFirstAdminClick = { showSetupAdminDialog = true },
                onOpenSettingsClick = { showSupabaseConfigDialog = true },
                isLoading = false,
                errorMessage = errorMsg
            )
        }
        is AuthState.Authenticated -> {
            val profile = state.profile
            if (profile.role == "student") {
                StudentFlow(
                    studentProfile = profile,
                    currentScreen = currentStudentScreen,
                    onNavigate = { currentStudentScreen = it },
                    onLogout = { authViewModel.logout() },
                    studentViewModel = studentViewModel!!
                )
            } else {
                AdminFlow(
                    adminProfile = profile,
                    currentScreen = currentAdminScreen,
                    selectedExamType = selectedExamTypeForTests,
                    onSelectExamType = { selectedExamTypeForTests = it },
                    onNavigate = { currentAdminScreen = it },
                    onLogout = { authViewModel.logout() },
                    onOpenSettings = { showSupabaseConfigDialog = true },
                    adminViewModel = adminViewModel!!
                )
            }
        }
    }
}

@Composable
private fun rememberInternetConnection(): Pair<Boolean, () -> Unit> {
    val context = androidx.compose.ui.platform.LocalContext.current
    val connectivityManager = remember {
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    }

    fun isOnline(): Boolean {
        val network = connectivityManager.activeNetwork ?: return false
        val capabilities = connectivityManager.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    var isConnected by remember { mutableStateOf(isOnline()) }

    DisposableEffect(connectivityManager) {
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                isConnected = isOnline()
            }

            override fun onLost(network: Network) {
                isConnected = isOnline()
            }

            override fun onCapabilitiesChanged(
                network: Network,
                networkCapabilities: NetworkCapabilities
            ) {
                isConnected = networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                    networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
            }
        }
        connectivityManager.registerDefaultNetworkCallback(callback)
        onDispose { connectivityManager.unregisterNetworkCallback(callback) }
    }

    return isConnected to { isConnected = isOnline() }
}

@Composable
private fun NoInternetScreen(onRetry: () -> Unit) {
    val infiniteTransition = androidx.compose.animation.core.rememberInfiniteTransition(label = "offline")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.05f,
        animationSpec = androidx.compose.animation.core.infiniteRepeatable(
            animation = androidx.compose.animation.core.tween(900),
            repeatMode = androidx.compose.animation.core.RepeatMode.Reverse
        ),
        label = "offlinePulse"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                androidx.compose.ui.graphics.Brush.verticalGradient(
                    listOf(Color(0xFF2457D6), Color(0xFF1F4FCC))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.CloudOff,
                contentDescription = "No Internet",
                tint = Color.White,
                modifier = Modifier
                    .size(150.dp)
                    .scale(pulse)
            )

            Spacer(modifier = Modifier.height(26.dp))

            Text(
                text = "ઈન્ટરનેટ કનેક્શન જરૂરી છે",
                color = Color(0xFFFF9800),
                fontSize = 30.sp,
                fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )

            Spacer(modifier = Modifier.height(18.dp))

            Text(
                text = "મોબાઇલ ડેટા અથવા Wi-Fi ચાલુ કરો અને\nઈન્ટરનેટ કનેક્શન ચકાસો.",
                color = Color.White,
                fontSize = 20.sp,
                lineHeight = 30.sp,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )

            Spacer(modifier = Modifier.height(54.dp))

            Button(
                onClick = onRetry,
                modifier = Modifier
                    .fillMaxWidth(0.88f)
                    .height(70.dp),
                shape = RoundedCornerShape(40.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFFF9800),
                    contentColor = Color.White
                )
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Retry",
                    modifier = Modifier.size(34.dp)
                )
                Spacer(modifier = Modifier.padding(horizontal = 7.dp))
                Text(
                    text = "ફરીથી ચકાસો",
                    fontSize = 24.sp,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Medium
                )
            }
        }
    }
}

@Composable
fun StudentFlow(
    studentProfile: LocalProfileEntity,
    currentScreen: String,
    onNavigate: (String) -> Unit,
    onLogout: () -> Unit,
    studentViewModel: StudentViewModel
) {
    val examTypeName = studentProfile.examTypeId ?: "Exam"

    when (currentScreen) {
        "STUDENT_DASHBOARD" -> {
            StudentDashboardScreen(
                studentProfile = studentProfile,
                examTypeName = examTypeName,
                onNavMyTests = { onNavigate("MY_TESTS") },
                onNavNotifications = { onNavigate("STUDENT_NOTIFICATIONS") },
                onNavResults = { onNavigate("STUDENT_RESULTS") },
                onNavProfile = { onNavigate("STUDENT_PROFILE") },
                onLogout = onLogout
            )
        }
        else -> {
            StudentDashboardScreen(
                studentProfile = studentProfile,
                examTypeName = examTypeName,
                onNavMyTests = { onNavigate("MY_TESTS") },
                onNavNotifications = { onNavigate("STUDENT_NOTIFICATIONS") },
                onNavResults = { onNavigate("STUDENT_RESULTS") },
                onNavProfile = { onNavigate("STUDENT_PROFILE") },
                onLogout = onLogout
            )
        }
    }
}

@Composable
fun AdminFlow(
    adminProfile: LocalProfileEntity,
    currentScreen: String,
    selectedExamType: ExamType?,
    onSelectExamType: (ExamType?) -> Unit,
    onNavigate: (String) -> Unit,
    onLogout: () -> Unit,
    onOpenSettings: () -> Unit,
    adminViewModel: AdminViewModel
) {
    val students by adminViewModel.students.collectAsState()
    val admins by adminViewModel.admins.collectAsState()
    val examTypes by adminViewModel.examTypes.collectAsState()
    val tests by adminViewModel.tests.collectAsState()
    val notifications by adminViewModel.notifications.collectAsState()
    val isLoading by adminViewModel.isLoading.collectAsState()

    LaunchedEffect(Unit) {
        adminViewModel.loadExamTypes()
        adminViewModel.loadStudents(adminProfile.examTypeId)
        adminViewModel.loadTests(adminProfile.examTypeId)
        adminViewModel.loadNotifications(adminProfile.examTypeId)
        if (adminProfile.isMainAdmin) {
            adminViewModel.loadAdmins()
            adminViewModel.loadResults()
        }
    }

    when (currentScreen) {
        "DASHBOARD" -> {
            AdminDashboardScreen(
                adminProfile = adminProfile,
                totalStudents = students.size,
                totalTests = tests.size,
                totalNotifications = notifications.size,
                totalAdmins = admins.size,
                onNavStudents = { onNavigate("STUDENT_MGMT") },
                onNavExamTypes = { onNavigate("EXAM_TYPES") },
                onNavNotifications = { onNavigate("NOTIFICATIONS_MGMT") },
                onNavAdminMgmt = { onNavigate("ADMIN_MGMT") },
                onNavResults = { onNavigate("RESULTS_MGMT") },
                onLogout = onLogout,
                onOpenSettings = onOpenSettings
            )
        }
        "STUDENT_MGMT" -> {
            AdminStudentMgmtScreen(
                students = students,
                examTypes = examTypes,
                adminProfileId = adminProfile.id,
                isLoading = isLoading,
                onBack = { onNavigate("DASHBOARD") },
                onAddStudent = { name, mobile, pass, examTypeId, creatorId ->
                    adminViewModel.addStudent(name, mobile, pass, examTypeId, creatorId)
                },
                onToggleActive = { pId, active ->
                    adminViewModel.toggleProfileActive(pId, active, adminProfile.examTypeId)
                },
                onDeleteStudent = { pId ->
                    adminViewModel.deleteProfile(pId, adminProfile.examTypeId)
                }
            )
        }
        "EXAM_TYPES" -> {
            AdminExamTypesScreen(
                examTypes = examTypes,
                allTests = tests,
                onBack = { onNavigate("DASHBOARD") },
                onSelectExamType = { examType ->
                    onSelectExamType(examType)
                    adminViewModel.loadTests(examType.id)
                    onNavigate("TEST_MGMT")
                }
            )
        }
        "TEST_MGMT" -> {
            val exam = selectedExamType ?: examTypes.firstOrNull() ?: ExamType("navodaya", "નવોદય")
            AdminTestsMgmtScreen(
                examType = exam,
                tests = tests,
                isLoading = isLoading,
                adminProfileId = adminProfile.id,
                onBack = { onNavigate("DASHBOARD") },
                onAddTest = { name, desc, duration, passing ->
                    adminViewModel.addTest(name, desc, exam.id, duration, passing, adminProfile.id)
                },
                onTogglePublish = { testId, status ->
                    adminViewModel.toggleTestStatus(testId, status, adminProfile.examTypeId)
                },
                onDeleteTest = { testId ->
                    adminViewModel.deleteTest(testId, adminProfile.examTypeId)
                },
                onManageQuestions = { test ->
                    adminViewModel.loadQuestions(test.id)
                }
            )
        }
        else -> {
            AdminDashboardScreen(
                adminProfile = adminProfile,
                totalStudents = students.size,
                totalTests = tests.size,
                totalNotifications = notifications.size,
                totalAdmins = admins.size,
                onNavStudents = { onNavigate("STUDENT_MGMT") },
                onNavExamTypes = { onNavigate("EXAM_TYPES") },
                onNavNotifications = { onNavigate("NOTIFICATIONS_MGMT") },
                onNavAdminMgmt = { onNavigate("ADMIN_MGMT") },
                onNavResults = { onNavigate("RESULTS_MGMT") },
                onLogout = onLogout,
                onOpenSettings = onOpenSettings
            )
        }
    }
}

package com.example.data.local

import android.content.Context
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

/**
 * Small SharedPreferences-backed local store.
 * It intentionally avoids Room/KSP so GitHub Actions can build this project
 * without annotation-processing/tooling failures.
 */
class AppDatabase(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(
        "test_mitra_local_store",
        Context.MODE_PRIVATE
    )

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val profileAdapter = moshi.adapter(LocalProfileEntity::class.java)
    private val activeTestAdapter = moshi.adapter(LocalActiveTestEntity::class.java)
    private val answersAdapter = moshi.adapter<List<LocalTestAnswerEntity>>(
        Types.newParameterizedType(List::class.java, LocalTestAnswerEntity::class.java)
    )

    fun localDao(): LocalDao = LocalDao(
        prefs = prefs,
        profileAdapter = profileAdapter,
        activeTestAdapter = activeTestAdapter,
        answersAdapter = answersAdapter
    )
}

class LocalDao internal constructor(
    private val prefs: android.content.SharedPreferences,
    private val profileAdapter: com.squareup.moshi.JsonAdapter<LocalProfileEntity>,
    private val activeTestAdapter: com.squareup.moshi.JsonAdapter<LocalActiveTestEntity>,
    private val answersAdapter: com.squareup.moshi.JsonAdapter<List<LocalTestAnswerEntity>>
) {
    suspend fun saveProfile(profile: LocalProfileEntity) {
        prefs.edit().putString(KEY_PROFILE, profileAdapter.toJson(profile)).apply()
    }

    suspend fun getProfile(): LocalProfileEntity? {
        val json = prefs.getString(KEY_PROFILE, null) ?: return null
        return runCatching { profileAdapter.fromJson(json) }.getOrNull()
    }

    suspend fun clearProfile() {
        prefs.edit().remove(KEY_PROFILE).apply()
    }

    suspend fun saveActiveTest(test: LocalActiveTestEntity) {
        prefs.edit().putString(KEY_ACTIVE_TEST, activeTestAdapter.toJson(test)).apply()
    }

    suspend fun getActiveTest(): LocalActiveTestEntity? {
        val json = prefs.getString(KEY_ACTIVE_TEST, null) ?: return null
        val value = runCatching { activeTestAdapter.fromJson(json) }.getOrNull()
        return value?.takeUnless { it.isSubmitted }
    }

    suspend fun markTestSubmitted(attemptId: String) {
        val current = runCatching {
            prefs.getString(KEY_ACTIVE_TEST, null)?.let { activeTestAdapter.fromJson(it) }
        }.getOrNull()
        if (current != null && current.attemptId == attemptId) {
            prefs.edit().putString(
                KEY_ACTIVE_TEST,
                activeTestAdapter.toJson(current.copy(isSubmitted = true))
            ).apply()
        }
    }

    suspend fun clearActiveTest() {
        prefs.edit().remove(KEY_ACTIVE_TEST).apply()
    }

    suspend fun saveAnswer(answer: LocalTestAnswerEntity) {
        val current = getAllAnswers().toMutableList()
        val index = current.indexOfFirst { it.id == answer.id }
        if (index >= 0) current[index] = answer else current.add(answer)
        prefs.edit().putString(KEY_ANSWERS, answersAdapter.toJson(current)).apply()
    }

    suspend fun getAnswersForAttempt(attemptId: String): List<LocalTestAnswerEntity> =
        getAllAnswers().filter { it.attemptId == attemptId }

    suspend fun clearAnswersForAttempt(attemptId: String) {
        val remaining = getAllAnswers().filterNot { it.attemptId == attemptId }
        prefs.edit().putString(KEY_ANSWERS, answersAdapter.toJson(remaining)).apply()
    }

    private fun getAllAnswers(): List<LocalTestAnswerEntity> {
        val json = prefs.getString(KEY_ANSWERS, null) ?: return emptyList()
        return runCatching { answersAdapter.fromJson(json) ?: emptyList() }.getOrDefault(emptyList())
    }

    private companion object {
        const val KEY_PROFILE = "profile"
        const val KEY_ACTIVE_TEST = "active_test"
        const val KEY_ANSWERS = "answers"
    }
}

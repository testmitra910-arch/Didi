package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.List
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.ExamType
import com.example.model.Test
import com.example.ui.theme.ColorNavodaya
import com.example.ui.theme.PrimaryBlue

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminTestsMgmtScreen(
    examType: ExamType,
    tests: List<Test>,
    isLoading: Boolean,
    adminProfileId: String,
    onBack: () -> Unit,
    onAddTest: (name: String, desc: String, duration: Int, passingMarks: Int) -> Unit,
    onTogglePublish: (testId: String, currentStatus: String) -> Unit,
    onDeleteTest: (testId: String) -> Unit,
    onManageQuestions: (Test) -> Unit
) {
    var showAddDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("${examType.name} - ટેસ્ટ મેનેજમેન્ટ", color = Color.White, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PrimaryBlue)
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = ColorNavodaya,
                contentColor = Color.White,
                modifier = Modifier.testTag("add_test_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Test")
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Color(0xFFF8FAFC))
        ) {
            if (isLoading) {
                CircularProgressIndicator(
                    color = PrimaryBlue,
                    modifier = Modifier.align(Alignment.Center)
                )
            } else if (tests.isEmpty()) {
                // Strict Empty State per prompt requirement
                Column(
                    modifier = Modifier.align(Alignment.Center),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        Icons.Default.Assignment,
                        contentDescription = null,
                        modifier = Modifier.padding(16.dp),
                        tint = Color.Gray
                    )
                    Text(
                        text = "હાલમાં કોઈ ટેસ્ટ ઉપલબ્ધ નથી.",
                        fontSize = 16.sp,
                        color = Color.Gray,
                        fontWeight = FontWeight.Medium
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(tests) { test ->
                        TestCardItem(
                            test = test,
                            onTogglePublish = { onTogglePublish(test.id, test.status) },
                            onDelete = { onDeleteTest(test.id) },
                            onManageQuestions = { onManageQuestions(test) }
                        )
                    }
                }
            }
        }

        if (showAddDialog) {
            AddTestDialog(
                onDismiss = { showAddDialog = false },
                onSubmit = { name, desc, duration, passingMarks ->
                    onAddTest(name, desc, duration, passingMarks)
                    showAddDialog = false
                }
            )
        }
    }
}

@Composable
private fun TestCardItem(
    test: Test,
    onTogglePublish: () -> Unit,
    onDelete: () -> Unit,
    onManageQuestions: () -> Unit
) {
    val isPublished = test.status == "published"

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = test.name,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.DarkGray
                )

                TextButton(onClick = onTogglePublish) {
                    Text(
                        text = if (isPublished) "Published 🟢" else "Draft 🔴",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            if (!test.description.isNull_or_blank()) {
                Text(text = test.description.orEmpty(), fontSize = 13.sp, color = Color.Gray)
                Spacer(modifier = Modifier.height(4.dp))
            }

            Text(
                text = "⏱️ સમય: ${test.durationMinutes} મિનિટ | પાસિંગ માર્ક્સ: ${test.passingMarks}",
                fontSize = 13.sp,
                color = PrimaryBlue,
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = onManageQuestions,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                    modifier = Modifier.testTag("manage_questions_btn_${test.id}")
                ) {
                    Icon(Icons.Default.List, contentDescription = null, modifier = Modifier.padding(end = 4.dp))
                    Text("પ્રશ્નો ઉમેરો / મેનેજ કરો")
                }

                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete Test", tint = Color(0xFFC62828))
                }
            }
        }
    }
}

@Composable
private fun AddTestDialog(
    onDismiss: () -> Unit,
    onSubmit: (name: String, desc: String, duration: Int, passingMarks: Int) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var durationText by remember { mutableStateOf("30") }
    var passingText by remember { mutableStateOf("33") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("નવી ટેસ્ટ ઉમેરો (Add Test)", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = PrimaryBlue)

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("ટેસ્ટનું નામ (Test Name)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("add_test_name_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = desc,
                    onValueChange = { desc = it },
                    label = { Text("વર્ણન (Description - Optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = durationText,
                    onValueChange = { durationText = it },
                    label = { Text("સમય (મિનિટમાં)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("add_test_duration_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = passingText,
                    onValueChange = { passingText = it },
                    label = { Text("પાસિંગ ગુણ (Passing Marks)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = {
                        val duration = durationText.toIntOrNull() ?: 30
                        val passing = passingText.toIntOrNull() ?: 33
                        if (name.isNotBlank()) {
                            onSubmit(name, desc, duration, passing)
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("save_test_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                ) {
                    Text("SAVE TEST", fontWeight = FontWeight.Bold)
                }

                TextButton(onClick = onDismiss) { Text("રદ કરો", color = Color.Gray) }
            }
        }
    }
}

private fun String?.isNull_or_blank(): Boolean {
    return this == null || this.trim().isEmpty()
}

-- ============================================================
-- TEST MITRA (ટેસ્ટ મિત્ર) - SUPABASE FULL DATABASE SCHEMA & RLS
-- PRODUCTION-READY DATABASE MIGRATION SCRIPT
-- ============================================================

-- Enable pgcrypto for UUID generation
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- 1. PROFILES TABLE
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    auth_id UUID UNIQUE, -- References auth.users(id) if Supabase Auth is used
    name TEXT NOT NULL,
    mobile_number TEXT UNIQUE NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('main_admin', 'admin', 'student')),
    is_active BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2. EXAM TYPES TABLE
CREATE TABLE IF NOT EXISTS public.exam_types (
    id TEXT PRIMARY KEY, -- e.g. 'navodaya', 'nmms', 'gyan_setu', 'gyan_sadhana', 'tet_1'
    name TEXT NOT NULL,
    description TEXT,
    is_active BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Insert Default 5 Exam Types (TET 1 included)
INSERT INTO public.exam_types (id, name, description) VALUES
('navodaya', 'નવોદય', 'નવોદય પ્રવેશ પરીક્ષા ટેસ્ટ'),
('nmms', 'NMMS', 'National Means Cum Merit Scholarship Test'),
('gyan_setu', 'જ્ઞાન સેતુ', 'જ્ઞાન સેતુ સ્કોલરશિપ ટેસ્ટ'),
('gyan_sadhana', 'જ્ઞાન સાધના', 'જ્ઞાન સાધના સ્કોલરશિપ ટેસ્ટ'),
('tet_1', 'TET 1', 'શિક્ષક યોગ્યતા કસોટી - ૧ (TET 1)')
ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name, description = EXCLUDED.description;

-- 3. ADMINS TABLE
CREATE TABLE IF NOT EXISTS public.admins (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    profile_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    assigned_exam_type_id TEXT REFERENCES public.exam_types(id) ON DELETE SET NULL,
    is_main_admin BOOLEAN NOT NULL DEFAULT false,
    is_active BOOLEAN NOT NULL DEFAULT true,
    created_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 4. STUDENTS TABLE
CREATE TABLE IF NOT EXISTS public.students (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    profile_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    exam_type_id TEXT NOT NULL REFERENCES public.exam_types(id) ON DELETE RESTRICT,
    is_active BOOLEAN NOT NULL DEFAULT true,
    created_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 5. TESTS TABLE
CREATE TABLE IF NOT EXISTS public.tests (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    exam_type_id TEXT NOT NULL REFERENCES public.exam_types(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    description TEXT,
    duration_minutes INT NOT NULL DEFAULT 30,
    passing_marks INT NOT NULL DEFAULT 33,
    status TEXT NOT NULL DEFAULT 'published' CHECK (status IN ('draft', 'published', 'unpublished')),
    created_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 6. QUESTIONS TABLE
CREATE TABLE IF NOT EXISTS public.questions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    test_id UUID NOT NULL REFERENCES public.tests(id) ON DELETE CASCADE,
    question_text TEXT NOT NULL,
    option_a TEXT NOT NULL,
    option_b TEXT NOT NULL,
    option_c TEXT NOT NULL,
    option_d TEXT NOT NULL,
    correct_answer TEXT NOT NULL CHECK (correct_answer IN ('A', 'B', 'C', 'D')),
    marks INT NOT NULL DEFAULT 1,
    question_order INT NOT NULL DEFAULT 1,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 7. NOTIFICATIONS TABLE
CREATE TABLE IF NOT EXISTS public.notifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    exam_type_id TEXT NOT NULL REFERENCES public.exam_types(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT true,
    created_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 8. TEST ATTEMPTS TABLE
CREATE TABLE IF NOT EXISTS public.test_attempts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    test_id UUID NOT NULL REFERENCES public.tests(id) ON DELETE CASCADE,
    student_id UUID NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
    started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    submitted_at TIMESTAMPTZ,
    time_taken_seconds INT NOT NULL DEFAULT 0,
    score INT NOT NULL DEFAULT 0,
    total_marks INT NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'in_progress' CHECK (status IN ('in_progress', 'completed', 'submitted', 'time_expired'))
);

-- 9. TEST ANSWERS TABLE
CREATE TABLE IF NOT EXISTS public.test_answers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    attempt_id UUID NOT NULL REFERENCES public.test_attempts(id) ON DELETE CASCADE,
    question_id UUID NOT NULL REFERENCES public.questions(id) ON DELETE CASCADE,
    selected_answer TEXT CHECK (selected_answer IN ('A', 'B', 'C', 'D', 'UNANSWERED')),
    is_correct BOOLEAN NOT NULL DEFAULT false,
    marks_obtained INT NOT NULL DEFAULT 0
);

-- 10. ACTIVE SESSIONS TABLE (One Account - One Active Device)
CREATE TABLE IF NOT EXISTS public.active_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    session_id TEXT NOT NULL,
    device_id TEXT NOT NULL,
    device_name TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_active_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    is_active BOOLEAN NOT NULL DEFAULT true
);

-- INDEXES FOR PERFORMANCE
CREATE INDEX IF NOT EXISTS idx_profiles_mobile ON public.profiles(mobile_number);
CREATE INDEX IF NOT EXISTS idx_students_exam_type ON public.students(exam_type_id);
CREATE INDEX IF NOT EXISTS idx_tests_exam_type ON public.tests(exam_type_id);
CREATE INDEX IF NOT EXISTS idx_questions_test_id ON public.questions(test_id);
CREATE INDEX IF NOT EXISTS idx_attempts_student ON public.test_attempts(student_id);
CREATE INDEX IF NOT EXISTS idx_active_sessions_user ON public.active_sessions(user_id);

-- ROW LEVEL SECURITY (RLS) POLICIES
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.exam_types ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admins ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.students ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.test_attempts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.test_answers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.active_sessions ENABLE ROW LEVEL SECURITY;

-- Allow anon read/write if using API keys directly
CREATE POLICY "Allow public anon access for app operations" ON public.profiles FOR ALL USING (true);
CREATE POLICY "Allow public anon access for exam_types" ON public.exam_types FOR ALL USING (true);
CREATE POLICY "Allow public anon access for admins" ON public.admins FOR ALL USING (true);
CREATE POLICY "Allow public anon access for students" ON public.students FOR ALL USING (true);
CREATE POLICY "Allow public anon access for tests" ON public.tests FOR ALL USING (true);
CREATE POLICY "Allow public anon access for questions" ON public.questions FOR ALL USING (true);
CREATE POLICY "Allow public anon access for notifications" ON public.notifications FOR ALL USING (true);
CREATE POLICY "Allow public anon access for test_attempts" ON public.test_attempts FOR ALL USING (true);
CREATE POLICY "Allow public anon access for test_answers" ON public.test_answers FOR ALL USING (true);
CREATE POLICY "Allow public anon access for active_sessions" ON public.active_sessions FOR ALL USING (true);
